import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EditEmployee from './EditEmployee';
import { AddEmployee } from './AddEmployee';

export const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [showAddEmployee, setShowAddEmployee] = useState(false); // Popup state

  useEffect(() => {
    axios.get('/api/employees')
      .then(response => {
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the employees!', error);
      });
  }, []);

  const handleEdit = (employee) => {
    setSelectedEmployee(employee); // Open edit form
  };

  const handleUpdate = () => {
    axios.get('/api/employees')
      .then(response => {
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the updated employees!', error);
      });

    setSelectedEmployee(null); // Close edit form after update
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/employees/${id}`);
      setEmployees(employees.filter(employee => employee.id !== id));
    } catch (error) {
      console.error('Error deleting employee:', error);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold">Employee List</h2>

      {/* Add Employee Button */}
      <button
        onClick={() => setShowAddEmployee(true)}
        className="mb-4 px-4 py-2 bg-green-500 text-white rounded"
      >
        Add Employee
      </button>

      {/* Add Employee Popup */}
      {showAddEmployee && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 className="text-lg font-semibold mb-4">Add Employee</h3>
            <AddEmployee />
            <button
              onClick={() => setShowAddEmployee(false)}
              className="mt-4 px-4 py-2 bg-gray-500 text-white rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {selectedEmployee ? (
        <div>
          <button
            onClick={() => setSelectedEmployee(null)}
            className="mb-4 px-3 py-1 text-white bg-gray-500 rounded"
          >
            Back to Employee List
          </button>
          <EditEmployee employee={selectedEmployee} onUpdate={handleUpdate} onDelete={handleDelete} />
        </div>
      ) : (
        <ul>
          {employees.map(employee => (
            <li key={employee.id} className="p-2 border-b flex justify-between items-center">
              <div>
                {employee.name} - {employee.email} - {employee.factory} - 
                {employee.is_active ? 'Active' : 'Inactive'} - ${employee.daily_wage}
              </div>
              <div>
                <button
                  onClick={() => handleEdit(employee)}
                  className="px-2 py-1 text-white bg-blue-500 rounded mr-2"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(employee.id)}
                  className="px-2 py-1 text-white bg-red-500 rounded"
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
